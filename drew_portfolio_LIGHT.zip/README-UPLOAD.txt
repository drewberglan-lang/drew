UPLOAD INSTRUCTIONS

This is the lighter version without the MP4 video file.

1. Download and unzip this file.
2. Upload index.html plus the files and projects folders to OU Create.
3. Keep the folder names exactly the same.
4. Upload your video separately if you want to include it.
5. Submit the link to index.html or your portfolio page.
